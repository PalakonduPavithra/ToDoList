document.addEventListener('DOMContentLoaded', function() {
    const loginContainer = document.getElementById('login-container');
    const signupContainer = document.getElementById('signup-container');
    const todoContainer = document.getElementById('todo-container');

    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const todoForm = document.getElementById('todo-form');
    const todoList = document.getElementById('todo-list');

    let currentUser = null;
    const users = [
        { username: 'user1', password: 'password1' },
        { username: 'user2', password: 'password2' }
    ];

    // Event listener for login form submission
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = loginForm.elements['username'].value;
        const password = loginForm.elements['password'].value;

        const user = users.find(u => u.username === username && u.password === password);
        if (user) {
            currentUser = user;
            loginForm.reset();
            showTodoPage();
        } else {
            alert('Invalid username or password. Please try again.');
        }
    });

    // Event listener for signup form submission
    signupForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const newUsername = signupForm.elements['new-username'].value;
        const newPassword = signupForm.elements['new-password'].value;

        users.push({ username: newUsername, password: newPassword });
        alert('Sign Up Successful! Please log in with your new credentials.');
        signupForm.reset();
        showLoginPage();
    });

    // Event listener for todo form submission (add/update task)
    todoForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const titleId = todoForm.elements['titleId'].value;
        const title = todoForm.elements['title'].value;
        const description = todoForm.elements['description'].value;
        const dueDate = todoForm.elements['duedate'].value;
        const status = todoForm.elements['status'].value;

        const task = { titleId, title, description, dueDate, status };
        if (todoForm.elements['editIndex'].value === '-1') {
            addToDoList(task);
        } else {
            updateToDoList(task, parseInt(todoForm.elements['editIndex'].value));
            todoForm.elements['editIndex'].value = '-1';
        }
        todoForm.reset();
    });

    // Function to add task to the to-do list
    function addToDoList(task) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${task.titleId}</td>
            <td>${task.title}</td>
            <td>${task.description}</td>
            <td>${task.dueDate}</td>
            <td>${task.status}</td>
            <td>
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </td>
        `;
        todoList.appendChild(row);

        const editBtn = row.querySelector('.edit-btn');
        editBtn.addEventListener('click', function() {
            editToDoList(task);
        });

        const deleteBtn = row.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', function() {
            row.remove();
        });
    }

    // Function to edit task in the to-do list
    function editToDoList(task) {
        todoForm.elements['titleId'].value = task.titleId;
        todoForm.elements['title'].value = task.title;
        todoForm.elements['description'].value = task.description;
        todoForm.elements['duedate'].value = task.dueDate;
        todoForm.elements['status'].value = task.status;
        todoForm.elements['editIndex'].value = Array.from(todoList.rows).indexOf(event.target.closest('tr')) - 1; // Calculate index of row in the table
    }

    // Function to update task in the to-do list
    function updateToDoList(task, index) {
        const row = todoList.rows[index + 1]; // index + 1 to skip the table header row
        row.cells[0].textContent = task.titleId;
        row.cells[1].textContent = task.title;
        row.cells[2].textContent = task.description;
        row.cells[3].textContent = task.dueDate;
        row.cells[4].textContent = task.status;
    }

    // Function to show login page
    function showLoginPage() {
        loginContainer.style.display = 'block';
        signupContainer.style.display = 'none';
        todoContainer.style.display = 'none';
    }

    // Function to show signup page
    function showSignupPage() {
        loginContainer.style.display = 'none';
        signupContainer.style.display = 'block';
        todoContainer.style.display = 'none';
    }

    // Function to show todo page (after successful login)
    function showTodoPage() {
        loginContainer.style.display = 'none';
        signupContainer.style.display = 'none';
        todoContainer.style.display = 'block';
    }

    // Event listener for "Sign Up" link
    document.getElementById('signup-link').addEventListener('click', function(event) {
        event.preventDefault();
        showSignupPage();
    });

    // Event listener for "Login" link (from sign up page)
    document.getElementById('return-to-login-link').addEventListener('click', function(event) {
        event.preventDefault();
        showLoginPage();
    });

    // Initialize: Show login page by default
    showLoginPage();
});
