const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const session = require('express-session');
const path = require('path');

const app = express();
const port = 3000;

// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Pavithra#3',
  database: 'todo_app'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the MySQL server.');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'your_secret_key',
  resave: true,
  saveUninitialized: true
}));

// Serve the HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// User registration
app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const sql = 'INSERT INTO userdetails (username, password) VALUES (?, ?)';
  connection.query(sql, [username, password], (err, result) => {
    if (err) {
      res.status(500).send('Registration failed. Please try again.');
    } else {
      res.send('Registration successful');
    }
  });
});

// User login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sql = 'SELECT * FROM userdetails WHERE username = ? AND password = ?';
  connection.query(sql, [username, password], (err, results) => {
    if (err || results.length === 0) {
      res.status(401).send('Invalid credentials. Please try again.');
    } else {
      req.session.loggedin = true;
      req.session.username = username;
      res.redirect('/');
    }
  });
});

// User logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.send('Logged out successfully');
});

// Add task
app.post('/todo', (req, res) => {
  const { titleId, title, description, dueDate, status } = req.body;
  const sql = 'INSERT INTO tasks (titleId, title, description, due_date, status) VALUES (?, ?, ?, ?, ?)';
  connection.query(sql, [titleId, title, description, dueDate, status], (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      res.status(500).send('Error inserting data into database');
    } else {
      console.log('Data inserted successfully');
      res.redirect('/');
    }
  });
});


// Retrieve tasks
app.get('/tasks', (req, res) => {
  if (!req.session.loggedin) {
    return res.status(401).send('Unauthorized');
  }
  const sql = 'SELECT * FROM todo WHERE userid = (SELECT userid FROM userdetails WHERE username = ?)';
  connection.query(sql, [req.session.username], (err, results) => {
    if (err) {
      res.status(500).send('Failed to fetch tasks');
    } else {
      res.json(results);
    }
  });
});

// Start server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
